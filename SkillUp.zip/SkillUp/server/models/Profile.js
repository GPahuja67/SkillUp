const mongoose = require("mongoose");

const ProfileSchema = new mongoose.Schema({
  interests: [String],
  learningTime: String,
  sessionDuration: Number,
  location: String,
  skillLevel: String,
  goals: String,
  profilePicture: String,    // file path or Base64
  expertiseSkills: String,
  portfolioFiles: [String],  // file paths or Base64
}, { timestamps: true });

module.exports = mongoose.model("Profile", ProfileSchema);
