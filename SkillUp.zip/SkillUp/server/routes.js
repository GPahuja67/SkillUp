const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("./models/User");
const Profile = require("./models/Profile");

const router = express.Router();

// ======================
// Auth Routes
// ======================

// Register
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Prevent duplicate users
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({ name, email, password: hashedPassword });
    await user.save();

    res.json({ message: "✅ User registered successfully" });
  } catch (err) {
    console.error("Register error:", err);
    res.status(400).json({ error: err.message });
  }
});

// Login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(400).json({ error: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

    res.json({ message: "✅ Login successful", user });
  } catch (err) {
    console.error("Login error:", err);
    res.status(400).json({ error: err.message });
  }
});

// ======================
// Profile Routes
// ======================

// Save profile
router.post("/profiles", async (req, res) => {
  try {
    const newProfile = new Profile(req.body);
    await newProfile.save();
    res.status(201).json({ message: "✅ Profile saved successfully!" });
  } catch (err) {
    console.error("Profile save error:", err);
    res.status(500).json({ error: "Error saving profile", details: err.message });
  }
});

// Fetch all profiles
router.get("/profiles", async (req, res) => {
  try {
    const profiles = await Profile.find();
    res.json(profiles);
  } catch (err) {
    console.error("Fetch profiles error:", err);
    res.status(500).json({ error: "Error fetching profiles" });
  }
});

module.exports = router;
