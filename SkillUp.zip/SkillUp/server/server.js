const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const connectDB = require('./db'); // your MongoDB connection
const routes = require('./routes'); // routes file
const path = require('path');

const app = express();
const PORT = 5000;

// Connect Database
connectDB();

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '20mb' })); // increased limit for images/files
app.use(bodyParser.urlencoded({ extended: true, limit: '20mb' }));

// API routes
app.use('/api', routes);

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../client')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/index.html'));
});

// Start server
app.listen(PORT, () => console.log(`✅ Server running at http://localhost:${PORT}`));
